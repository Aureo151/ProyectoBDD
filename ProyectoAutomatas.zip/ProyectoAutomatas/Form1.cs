﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Net.Http;
using System.Web.Script.Serialization;

namespace ProyectoAutomatas
{
    public partial class Form1 : Form
    {
        public class RespuestaRFID
        {
            public string uid { get; set; }
        }
        private JavaScriptSerializer serializer = new JavaScriptSerializer();
        private HttpClient clienteHTTP = new HttpClient();
        private Timer timerRFIDWifi = new Timer();
        private string ipESP32 = "";
        private bool peticionEnCurso = false; // ← Evita peticiones concurrentes
        private SerialPort puertoRFID;

        private readonly Dictionary<string, string> usuarios = new Dictionary<string, string>()
    {
        { "admin", "1234" },
        { "operador", "2026" }
    };

        private readonly HashSet<string> tarjetasAutorizadas = new HashSet<string>()
    {
        "A1B2C3",
        "RFID2026",
        "CARD01"
    };

        public Form1()
        {
            InitializeComponent();

            // Timer para polling WiFi cada 1 segundo
            timerRFIDWifi.Interval = 1000;
            timerRFIDWifi.Tick += TimerRFIDWifi_Tick;

            // Timeout para evitar que el HttpClient se quede colgado
            clienteHTTP.Timeout = TimeSpan.FromSeconds(3);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CargarPuertos();
            ActualizarBotones(modoWifi: false, conectado: false);
        }

        // ─── LOGIN ────────────────────────────────────────────────────────────────

        private void button1_Click(object sender, EventArgs e) // Botón "Iniciar sesión"
        {
            string usuario = textBox1.Text.Trim();
            string contraseña = textBox2.Text;

            if (string.IsNullOrEmpty(usuario) || string.IsNullOrEmpty(contraseña))
            {
                label5.Text = "Estado: ingrese usuario y contraseña.";
                return;
            }

            if (usuarios.TryGetValue(usuario, out string claveCorrecta) && claveCorrecta == contraseña)
            {
                AbrirFormularioPrincipal(usuario);
            }
            else
            {
                label5.Text = "Estado: usuario o contraseña incorrectos.";
                MessageBox.Show("Usuario o contraseña incorrectos.", "Error de acceso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ─── RFID SERIAL ─────────────────────────────────────────────────────────

        private void CargarPuertos()
        {
            comboBox1.Items.Clear();
            string[] puertos = SerialPort.GetPortNames();
            foreach (string p in puertos)
                comboBox1.Items.Add(p);

            if (comboBox1.Items.Count > 0)
                comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e) // Botón "Conectar RFID Serial"
        {
            // Si ya está conectado, desconectar
            if (puertoRFID != null && puertoRFID.IsOpen)
            {
                puertoRFID.Close();
                puertoRFID.Dispose();
                puertoRFID = null;
                label5.Text = "Estado: lector RFID desconectado.";
                button2.Text = "Conectar RFID Serial";
                return;
            }

            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Seleccione un puerto COM.");
                return;
            }

            try
            {
                string puerto = comboBox1.SelectedItem.ToString();
                puertoRFID = new SerialPort(puerto, 9600) { NewLine = "\n" };
                puertoRFID.DataReceived += PuertoRFID_DataReceived;
                puertoRFID.Open();

                label5.Text = $"Estado: lector RFID conectado en {puerto}";
                button2.Text = "Desconectar RFID Serial";

                // Detener WiFi si estaba activo
                DetenerWifi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo conectar al lector RFID.\n\n" + ex.Message,
                    "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PuertoRFID_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string codigoRFID = puertoRFID.ReadLine().Trim().ToUpper();

                this.Invoke(new Action(() => ValidarRFID(codigoRFID)));
            }
            catch (Exception ex)
            {
                this.Invoke(new Action(() =>
                    label5.Text = "Error al leer RFID: " + ex.Message));
            }
        }

        // ─── RFID WIFI (ESP32) ───────────────────────────────────────────────────

        private void button4_Click(object sender, EventArgs e) // Botón "Conectar WiFi"
        {
            // Si ya está corriendo, detener
            if (timerRFIDWifi.Enabled)
            {
                DetenerWifi();
                return;
            }

            string ip = textBox3.Text.Trim();

            if (string.IsNullOrEmpty(ip))
            {
                MessageBox.Show("Ingrese la IP del ESP32.", "IP requerida",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validación básica de formato IP
            if (!EsIPValida(ip))
            {
                MessageBox.Show("La IP ingresada no tiene un formato válido.\nEjemplo: 192.168.1.100",
                    "IP inválida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ipESP32 = ip;

            // Detener RFID serial si estaba activo
            if (puertoRFID != null && puertoRFID.IsOpen)
            {
                puertoRFID.Close();
                puertoRFID.Dispose();
                puertoRFID = null;
                button2.Text = "Conectar RFID Serial";
            }

            timerRFIDWifi.Start();
            button4.Text = "Detener WiFi";
            label5.Text = $"Estado: esperando tarjeta RFID por WiFi ({ipESP32})...";
        }

        private async void TimerRFIDWifi_Tick(object sender, EventArgs e)
        {
            if (peticionEnCurso) return;
            peticionEnCurso = true;

            try
            {
                string url = "http://" + ipESP32 + "/uid";
                string respuesta = await clienteHTTP.GetStringAsync(url);

                RespuestaRFID datos = serializer.Deserialize<RespuestaRFID>(respuesta);

                string codigoRFID = "";

                if (datos != null && !string.IsNullOrEmpty(datos.uid))
                {
                    codigoRFID = datos.uid.Trim().ToUpper();
                }

                if (!string.IsNullOrEmpty(codigoRFID))
                {
                    timerRFIDWifi.Stop();

                    await clienteHTTP.GetStringAsync("http://" + ipESP32 + "/clear");

                    ValidarRFID(codigoRFID);

                    timerRFIDWifi.Start();
                }
            }
            catch (TaskCanceledException)
            {
                label5.Text = "ESP32 no responde (timeout).";
            }
            catch (HttpRequestException)
            {
                label5.Text = "Sin conexion con " + ipESP32 + ".";
            }
            catch (Exception ex)
            {
                label5.Text = "Error WiFi: " + ex.Message;
            }
            finally
            {
                peticionEnCurso = false;
            }
        }

        // ─── VALIDACIÓN RFID Y ACCESO ─────────────────────────────────────────────

        private void ValidarRFID(string codigoRFID)
        {
            label5.Text = $"Estado: tarjeta detectada → {codigoRFID}";

            if (tarjetasAutorizadas.Contains(codigoRFID))
            {
                label5.Text = $"Estado: acceso concedido ({codigoRFID})";
                AbrirFormularioPrincipal("RFID");
            }
            else
            {
                label5.Text = $"Estado: tarjeta no autorizada ({codigoRFID})";
                MessageBox.Show($"Tarjeta RFID no autorizada:\n{codigoRFID}", "Acceso denegado",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void AbrirFormularioPrincipal(string usuarioOrigen)
        {
            frmFormularioPrincipal formulario = new frmFormularioPrincipal(usuarioOrigen);
            formulario.Show();
            this.Hide(); 
        }

        

        private void DetenerWifi()
        {
            timerRFIDWifi.Stop();
            button4.Text = "Conectar WiFi ESP32";
            label5.Text = "Estado: monitoreo WiFi detenido.";
        }

        private bool EsIPValida(string ip)
        {
            // Acepta IPv4 o nombre de host simple
            if (System.Net.IPAddress.TryParse(ip, out _)) return true;
            // También permite hostnames como "esp32.local"
            return System.Text.RegularExpressions.Regex.IsMatch(ip,
                @"^[a-zA-Z0-9]([a-zA-Z0-9\-\.]{0,61}[a-zA-Z0-9])?$");
        }

        private void ActualizarBotones(bool modoWifi, bool conectado)
        {
            button2.Text = conectado && !modoWifi ? "Desconectar RFID Serial" : "Conectar RFID Serial";
            button4.Text = conectado && modoWifi ? "Detener WiFi" : "Conectar WiFi ESP32";
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            timerRFIDWifi.Stop();
            puertoRFID?.Close();
            clienteHTTP.Dispose();
            base.OnFormClosing(e);
        }
    }
}
